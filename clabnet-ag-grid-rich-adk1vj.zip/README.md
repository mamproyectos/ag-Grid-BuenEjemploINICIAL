
ag-Grid-angular-examples - angular-cli
==================================

Example of using ag-Grid with Angular and TypeScript

**Note** We only show the "Rich Grid" example in use here. For the full set of examples please look under the **../ngtools_webpack** folder

Building
========

Install Dependencies:

- `npm install`

Dev Server
=========

To build & run:

- `ng serve`

Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

Building
========

To build:

- `ng build`

To do a prod build:

- `ng build --prod`

To do a AOT build:

- `ng build --aot`

The build artifacts will be stored in the `dist/` directory.
